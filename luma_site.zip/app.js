
async function loadManifest(){
  const res = await fetch('./manifest.json');
  return res.json();
}

// Populate library grid
async function populateLibrary(){
  const root = document.querySelector('#library-grid');
  if(!root) return;
  const m = await loadManifest();
  m.stories.forEach(s => {
    const cover = s.images.find(x => /\.(png|jpg|jpeg|webp|gif)$/i.test(x)) || '';
    const a = document.createElement('a');
    a.href = `stories/${s.id}.html`;
    a.className='card';
    a.innerHTML = `
      <img class="story-cover" src="assets/${cover}" alt="${s.title}"/>
      <h3 style="margin:12px 0 4px">${s.title}</h3>
      <div class="tag">${s.emotion || 'Émotion à définir'} • 4–9 ans</div>
    `;
    root.appendChild(a);
  })
}

// Populate story page
async function populateStory(storyId){
  const data = await loadManifest();
  const story = data.stories.find(s => String(s.id) === String(storyId));
  if(!story) return;
  document.querySelector('#story-title').textContent = story.title;
  document.querySelector('#story-emotion').textContent = story.emotion || 'Émotion à définir';
  const gallery = document.querySelector('#story-gallery');
  story.images.forEach(img => {
    const fig = document.createElement('figure');
    fig.className='card';
    fig.innerHTML = `<img class="story-hero" src="../assets/${img}" alt="${story.title}">`;
    gallery.appendChild(fig);
  });
}

document.addEventListener('DOMContentLoaded', ()=>{
  if (document.querySelector('#library-grid')) populateLibrary();
  const page = document.body.dataset.page;
  if (page === 'story'){
    const id = document.body.dataset.id;
    populateStory(id);
  }
});
