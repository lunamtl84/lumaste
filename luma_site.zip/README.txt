
Luma – Site Statique (Prototype)
================================

Ce dossier contient :
- index.html (landing), library.html (bibliothèque), stories/{id}.html (pages d'histoires)
- styles.css, app.js
- assets/ (extraits du ZIP importé)
- manifest.json (liste des histoires + images)
- webflow_cms/emotions.csv et stories.csv (fichiers d'import Webflow)

Utilisation locale
------------------
Ouvrir index.html dans un navigateur ou servir le dossier (ex: `python -m http.server` puis http://localhost:8000).

Import Webflow (optionnel)
--------------------------
1) Créer deux Collections CMS : "Émotions" (Name, ColorHex, Description) et "Histoires" (Name, Emotion (référence), AgeMin, AgeMax, Synopsis, CoverImage, Slug).
2) Importer `webflow_cms/emotions.csv`, puis `webflow_cms/stories.csv` (mapper CoverImagePath après avoir uploadé les images d'assets/).
3) Lier vos pages CMS à un template : page Histoire avec image cover, champ Emotion, texte, galerie (répéter sur la base d'assets).

Personnalisation
----------------
- Renseigner l'émotion, le synopsis et le texte de chaque histoire sur Webflow ou dans `stories/{id}.html`.
- Remplacer les images de couverture si nécessaire.

Généré : 2025-08-11T08:25:18.659734Z
